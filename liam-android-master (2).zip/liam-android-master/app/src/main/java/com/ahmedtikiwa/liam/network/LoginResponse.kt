package com.ahmedtikiwa.liam.network

class LoginResponse {
}