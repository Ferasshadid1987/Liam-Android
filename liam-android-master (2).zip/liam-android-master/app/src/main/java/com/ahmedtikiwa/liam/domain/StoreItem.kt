package com.ahmedtikiwa.liam.domain

data class StoreItem(
    var name: String?,
    var likes : String?,
    var downloads : String?,
    var price: String?,
    var imageUrl : String?
)